# AI YouTube Shorts Generator

Automatically turn a topic into a vertical 9:16 YouTube Short:

1. Research facts (Wikipedia, free)
2. Write a hook + body + follow CTA
3. Generate a natural male voiceover (Microsoft Edge TTS, free, no key)
4. Find relevant royalty-free video/photos (Pexels / Pixabay / Unsplash / Wikimedia)
5. Edit scenes with motion, captions, and quiet background music
6. Export an H.264 1080x1920 MP4 plus YouTube title, description, tags, and sources

GitHub repository name: **ai-video-gen**

This project is designed so the **basic pipeline works with zero paid APIs**. Optional free API keys improve script quality and stock footage.

## 1. Install

### Windows

1. Install Python 3.10+ from https://www.python.org/downloads/  
   Check **Add python.exe to PATH**.
2. Install FFmpeg:  
   - `winget install FFmpeg`  
   - or download from https://ffmpeg.org and add it to PATH
3. Open PowerShell in this folder:

```powershell
python -m venv .venv
.\.venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
```

### Linux / macOS

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

FFmpeg is required:

```bash
# Debian / Ubuntu
sudo apt-get update && sudo apt-get install -y ffmpeg

# macOS
brew install ffmpeg
```

## 2. Which free API keys are needed?

**None are required to run a first Short.**

| Purpose | Service | Required? | Free limit | Get a key |
|---|---|---|---|---|
| Voice | edge-tts (Microsoft Edge neural voices) | No key | Practical personal use | already included |
| Voice fallback | gTTS | No key | Google unofficial limit | already included |
| Facts | Wikipedia / Wikimedia APIs | No key | Public API etiquette | already included |
| Better script writing | Groq | Optional | Free daily token quota | https://console.groq.com |
| Better script writing | Gemini | Optional | Free tier from Google AI Studio | https://aistudio.google.com/apikey |
| Stock video + photos | Pexels | Optional but recommended | 200 requests/hour, 20,000/month | https://www.pexels.com/api/ |
| Stock video + photos + music | Pixabay | Optional | 100 requests/minute | https://pixabay.com/api/docs/ |
| Photos | Unsplash | Optional | Demo: 50 requests/hour | https://unsplash.com/developers |

If every stock API is missing, the generator still runs: it uses Wikimedia Commons media when possible, then a cinematic generated backdrop with camera movement.

Do **not** put keys in source files. Use `.env` only.

## 3. Where to put API keys

1. Copy `.env.example` to `.env`
2. Paste keys after the `=` signs
3. Never commit `.env` (it is gitignored)

Example:

```
GROQ_API_KEY=gsk_...
PEXELS_API_KEY=...
PIXABAY_API_KEY=...
```

## 4. Generate one Short

```bash
python main.py --topic "The most insane facts about Minecraft"
```

or edit `topics.txt` and run:

```bash
python main.py
```

That uses the first non-empty line in `topics.txt`.

Useful flags:

```bash
python main.py --topic "Amazing space facts" --duration 40
python main.py --topic "Engineering facts" --no-music
```

Progress looks like:

```
[1/8] Researching topic…
[2/8] Writing script…
[3/8] Generating voice…
[4/8] Finding visuals…
[5/8] Building scenes…
[6/8] Creating captions…
[7/8] Rendering video…
[8/8] Creating YouTube metadata…
```

Outputs (per run folder plus a latest copy):

- `output/<topic>-<timestamp>/video.mp4`
- `output/video.mp4`
- `output/title.txt`
- `output/description.txt`
- `output/tags.txt`
- `output/metadata.json`
- plus `script.txt`, `sources.txt`, `captions.srt` inside the run folder

Default export: **1080x1920, 30fps, H.264 + AAC, YouTube Shorts compatible**, usually 30–60 seconds.

## 5. Generate multiple Shorts

Put one topic per line in `topics.txt`:

```
Minecraft facts
Insane military facts
Space facts
Amazing engineering facts
```

Then:

```bash
python main.py --all
```

## 6. Enable GitHub Actions

1. Create a GitHub repo named `ai-video-gen`
2. Push this project
3. Repo → **Settings → Secrets and variables → Actions**
4. Add any keys you have as secrets: `GROQ_API_KEY`, `GEMINI_API_KEY`, `PEXELS_API_KEY`, `PIXABAY_API_KEY`, `UNSPLASH_ACCESS_KEY`
5. Open **Actions → Generate Short → Run workflow**
6. Type a topic and run

The workflow is `.github/workflows/generate.yml` (`workflow_dispatch` only).  
GitHub-hosted runners can render a short clip, but 1080x1920 encode may take several minutes. If the job times out, run the same command on your PC.

## 7. If an API hits its free limit

The generator already falls back in this order:

- Script: Groq → Gemini → OpenAI-compatible → Wikipedia template writer
- Voice: configured provider → fallback provider → edge-tts → gTTS
- Visuals: Pexels video → Pixabay video → Wikimedia video → Pexels photo → Pixabay photo → Unsplash → Wikimedia photo → generated motion backdrop
- Music: file in `assets/music/` → Pixabay audio → generated ambient bed

What you can do:

- Wait for the hourly/daily quota to reset
- Switch the missing service off by leaving its key empty
- Drop any `.mp3` / `.wav` into `assets/music/`
- Change `voice.voice` in `config.json` (see voices below)

## Configuration

Edit `config.json`:

- `video.width` / `height` / `fps` / `target_duration` / `bitrate`
- `voice.provider` (`edge` or `gtts`)
- `voice.voice` (Edge neural voice name)
- `music.enabled`
- `captions.style`, font size, highlight colour
- `scenes.min_count` / `max_count`
- `output_folder`

Natural male default voice: `en-US-AndrewNeural`  
Other free Edge voices: `en-US-BrianNeural`, `en-US-GuyNeural`, `en-GB-RyanNeural`.

List voices:

```bash
edge-tts --list-voices
```

## Quality notes

- Facts come from Wikipedia extracts. The writer is instructed not to invent numbers.
- Sources are saved to `sources.txt`.
- Stock APIs return reusable Pexels / Pixabay / Unsplash / Commons media. Still follow each site's attribution rules when you publish.
- Do not add copyrighted game cutscenes or movie clips to `assets/`.
- Captions are built from the real TTS word timings (Edge), not a guess.

## Project layout

```
ai-shorts-generator/
├── main.py
├── config.json
├── requirements.txt
├── .env.example
├── topics.txt
├── src/
│   ├── script_generator.py
│   ├── fact_checker.py
│   ├── voice_generator.py
│   ├── visual_search.py
│   ├── scene_generator.py
│   ├── video_editor.py
│   ├── captions.py
│   ├── music.py
│   ├── metadata.py
│   └── utils.py
├── assets/fonts/
├── assets/music/
├── output/
└── .github/workflows/generate.yml
```

## License

MIT. Bundled Lato fonts are SIL Open Font License.
