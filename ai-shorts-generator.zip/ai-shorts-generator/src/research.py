"""Research a topic using Wikipedia (always free) plus optional web snippets."""

from __future__ import annotations

import re
from typing import Any
from urllib.parse import quote

from .utils import http_get, info, unique_keep_order, warn

WIKI_API = "https://en.wikipedia.org/w/api.php"
WIKI_SUMMARY = "https://en.wikipedia.org/api/rest_v1/page/summary/"
WIKI_SEARCH = "https://en.wikipedia.org/w/rest.php/v1/search/page"


_FILLER = {
    "amazing", "insane", "wild", "crazy", "facts", "fact", "most", "about",
    "the", "that", "sound", "fake", "people", "never", "hear", "quick",
    "best", "top", "cool", "weird", "unbelievable", "secret", "secrets",
}


def clean_topic_query(topic: str) -> str:
    low = topic.lower()
    words = re.findall(r"[A-Za-z][A-Za-z0-9+\-]{2,}", topic)
    kept = [w for w in words if w.lower() not in _FILLER]
    core = " ".join(kept) or topic
    if "minecraft" in low:
        return "Minecraft"
    if "space" in low and "myspace" not in low:
        return "outer space"
    if "engineering" in low:
        return "engineering"
    if "military" in low:
        return "military history"
    return core


def research_topic(topic: str, language: str = "en") -> dict[str, Any]:
    """Return structured research: facts, sources, keywords, summary."""
    info(f"Researching: {topic}")
    query = clean_topic_query(topic)
    pages = _wiki_search(query, limit=5) or _wiki_search(topic, limit=5)
    facts: list[str] = []
    sources: list[dict[str, str]] = []
    summary = ""
    keywords = _seed_keywords(topic)

    for page in pages:
        title = page.get("title") or page.get("key") or ""
        if not title or _off_topic_title(title, topic):
            continue
        extract, url = _wiki_extract(title)
        if not extract:
            continue
        if not summary:
            summary = extract[:600]
        sources.append({"title": title, "url": url, "type": "wikipedia"})
        for sentence in _fact_sentences(extract, topic):
            facts.append(sentence)
        keywords.extend(_keywords_from_title(title))

    facts = unique_keep_order(facts)[:18]
    if not facts:
        warn("Wikipedia returned few facts; using topic-derived talking points")
        facts = _fallback_talking_points(topic)

    keywords = unique_keep_order(keywords)[:16]
    return {
        "topic": topic,
        "summary": summary or topic,
        "facts": facts,
        "sources": sources,
        "keywords": keywords,
        "language": language,
    }


def _wiki_search(topic: str, limit: int = 5) -> list[dict[str, Any]]:
    resp = http_get(
        WIKI_API,
        params={
            "action": "query",
            "list": "search",
            "srsearch": topic,
            "srlimit": str(limit),
            "format": "json",
            "utf8": "1",
        },
    )
    if resp is None:
        return []
    try:
        data = resp.json()
        return data.get("query", {}).get("search", []) or []
    except ValueError:
        return []


def _wiki_extract(title: str) -> tuple[str, str]:
    resp = http_get(
        WIKI_API,
        params={
            "action": "query",
            "prop": "extracts|info",
            "exintro": "1",
            "explaintext": "1",
            "redirects": "1",
            "inprop": "url",
            "titles": title,
            "format": "json",
            "utf8": "1",
        },
    )
    if resp is None:
        # REST summary fallback
        s = http_get(WIKI_SUMMARY + quote(title.replace(" ", "_")))
        if s is None:
            return "", ""
        try:
            payload = s.json()
            return (payload.get("extract") or "", payload.get("content_urls", {}).get("desktop", {}).get("page") or "")
        except ValueError:
            return "", ""
    try:
        pages = resp.json().get("query", {}).get("pages", {})
        for page in pages.values():
            extract = (page.get("extract") or "").strip()
            url = page.get("fullurl") or f"https://en.wikipedia.org/wiki/{quote(title.replace(' ', '_'))}"
            return extract, url
    except ValueError:
        return "", ""
    return "", ""


def _fact_sentences(extract: str, topic: str) -> list[str]:
    text = re.sub(r"\s+", " ", extract).strip()
    parts = re.split(r"(?<=[.!?])\s+", text)
    out: list[str] = []
    skip_prefixes = (
        "this article",
        "coordinates",
        "see also",
        "references",
        "citation needed",
    )
    for part in parts:
        sentence = part.strip()
        low = sentence.lower()
        if len(sentence) < 40 or len(sentence) > 240:
            continue
        if any(low.startswith(p) or p in low for p in skip_prefixes):
            continue
        if sentence.count(",") > 6:
            continue
        out.append(sentence)
    return out[:10]


def _seed_keywords(topic: str) -> list[str]:
    words = re.findall(r"[A-Za-z][A-Za-z0-9+\-]{2,}", topic)
    base = [" ".join(words)] if words else [topic]
    extras = []
    low = topic.lower()
    if "minecraft" in low:
        extras += ["minecraft gameplay", "minecraft world", "blocky landscape", "crafting table"]
    if "space" in low:
        extras += ["outer space nebula", "planet earth from orbit", "rocket launch"]
    if "military" in low or "tank" in low:
        extras += ["military vehicle field", "training range"]
    if "engineering" in low:
        extras += ["construction site aerial", "bridge engineering", "factory machines"]
    if "ocean" in low or "sea" in low:
        extras += ["ocean waves aerial", "underwater reef"]
    return base + extras + words


def _keywords_from_title(title: str) -> list[str]:
    return [title, title.replace("(", "").replace(")", "")]


def _fallback_talking_points(topic: str) -> list[str]:
    return [
        f"{topic} has a surprising history that most people never hear about.",
        f"Researchers and creators keep uncovering new details about {topic}.",
        f"Scale, speed, and design choices around {topic} are easy to underestimate.",
        f"Public records and encyclopedic sources still surprise people who look closer at {topic}.",
    ]


def _off_topic_title(title: str, topic: str) -> bool:
    low = title.lower()
    topic_l = topic.lower()
    if "disambiguation" in low:
        return True
    blocked = (
        "film", "movie", "album", "song", "novel", "episode",
        "video game", "tv series", "television",
        "klown", "killer", "adult", "porn",
        "kernel space", "user space", "nonprofit",
    )
    if any(b in low for b in blocked) and not any(b in topic_l for b in blocked):
        return True
    junk = ("charitable", "company", "surname", "festival")
    return any(j in low for j in junk) and not any(j in topic_l for j in junk)
