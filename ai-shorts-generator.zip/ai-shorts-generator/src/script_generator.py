"""Write a Shorts script from researched facts. Never invent statistics."""

from __future__ import annotations

import json
import re
from typing import Any, Optional

from .config_loader import env
from .fact_checker import filter_script_to_sources
from .utils import http_get, info, split_sentences, unique_keep_order, warn

try:
    import requests
except ImportError:  # pragma: no cover
    requests = None


def generate_script(
    research: dict[str, Any],
    target_duration: int = 45,
    language: str = "en",
) -> dict[str, Any]:
    facts = research.get("facts") or []
    topic = research.get("topic") or "this topic"
    llm_script = _try_llm_script(topic, facts, target_duration, language)
    if llm_script:
        script = llm_script
        info("Script written with optional LLM")
    else:
        info("Script written from Wikipedia facts (no LLM key)")
        script = _template_script(topic, facts, target_duration)

    script["full_narration"] = _compose_narration(script)
    script["scenes"] = _plan_scenes(script, research)
    script["sources"] = research.get("sources") or []
    return script


def _compose_narration(script: dict[str, Any]) -> str:
    parts = [script.get("hook", "")]
    parts.extend(script.get("body") or [])
    parts.append(script.get("ending", ""))
    text = " ".join(p.strip() for p in parts if p and p.strip())
    return re.sub(r"\s+", " ", text).strip()


def _template_script(topic: str, facts: list[str], target_duration: int) -> dict[str, Any]:
    usable = unique_keep_order([f for f in facts if len(f) > 35])[:8]
    if not usable:
        usable = [
            f"Public sources still surprise people who look closely at {topic}.",
            f"The details behind {topic} are stranger than the headlines.",
        ]
    hook = _hook_from_fact(topic, usable[0])
    # ~2.6 words/sec speaking pace with slight energy
    budget = max(55, int(target_duration * 2.4))
    body: list[str] = []
    used = len(hook.split())
    for fact in usable:
        short = _tighten(fact)
        if used + len(short.split()) > budget:
            break
        if short.lower() not in hook.lower():
            body.append(short)
            used += len(short.split())
    if not body:
        body = [_tighten(usable[0])]
    ending = "If you want more quick facts like this, follow for the next Short."
    return {
        "hook": hook,
        "body": body,
        "ending": ending,
        "title_seed": topic,
        "provider": "template",
    }


def _hook_from_fact(topic: str, fact: str) -> str:
    from .research import clean_topic_query
    clean = _tighten(fact)
    label = clean_topic_query(topic)
    if len(clean.split()) <= 18:
        return f"Most people have no idea this is true about {label}. {clean}"
    return f"Stop scrolling. This {label} fact is actually real. {clean}"


def _tighten(sentence: str) -> str:
    s = re.sub(r"\s+", " ", sentence).strip()
    s = re.sub(r"\([^)]*\)", "", s)
    s = re.sub(r"\s+", " ", s).strip()
    if not s.endswith((".", "!", "?")):
        s += "."
    # Keep it punchy
    words = s.split()
    if len(words) > 32:
        s = " ".join(words[:32]).rstrip(",;:") + "."
    return s


def _try_llm_script(
    topic: str,
    facts: list[str],
    target_duration: int,
    language: str,
) -> Optional[dict[str, Any]]:
    prompt = _prompt(topic, facts, target_duration, language)
    raw = _groq_complete(prompt) or _gemini_complete(prompt) or _openai_compatible(prompt)
    if not raw:
        return None
    parsed = _parse_llm_json(raw)
    if not parsed:
        return None
    hook = str(parsed.get("hook") or "").strip()
    body = parsed.get("body") or []
    if isinstance(body, str):
        body = split_sentences(body)
    body = [str(x).strip() for x in body if str(x).strip()]
    ending = str(parsed.get("ending") or "").strip()
    if not hook or not body:
        return None
    body = filter_script_to_sources(body, facts)
    if not body:
        return None
    return {
        "hook": hook,
        "body": body[:8],
        "ending": ending
        or "Follow if you want the next set of facts.",
        "title_seed": str(parsed.get("title") or topic),
        "provider": parsed.get("_provider", "llm"),
    }


def _prompt(topic: str, facts: list[str], target_duration: int, language: str) -> str:
    fact_block = "\n".join(f"- {f}" for f in facts[:12]) or "- No extra encyclopedia facts found."
    return f"""Write a YouTube Shorts narration script in {language}.
Topic: {topic}
Target spoken length: about {target_duration} seconds (roughly {int(target_duration*2.3)} words).

RULES:
- Use ONLY the facts listed below. Do not invent numbers, names, dates, or events.
- If a detail is not in the list, do not add it.
- Hook must grab attention in the first sentence.
- Body should be fast, clear, and spoken out loud.
- Ending should invite a follow, without sounding desperate.
- No hashtags in the spoken script.
- No claims that the video is "insane" unless the fact itself is surprising.

FACTS:
{fact_block}

Return ONLY valid JSON with keys:
hook (string),
body (array of 3 to 7 short sentences),
ending (string),
title (string, under 70 characters, not clickbait-false)
"""


def _groq_complete(prompt: str) -> Optional[str]:
    key = env("GROQ_API_KEY")
    if not key:
        return None
    try:
        resp = requests.post(
            "https://api.groq.com/openai/v1/chat/completions",
            headers={
                "Authorization": f"Bearer {key}",
                "Content-Type": "application/json",
            },
            json={
                "model": env("GROQ_MODEL", "llama-3.1-8b-instant"),
                "temperature": 0.4,
                "messages": [
                    {
                        "role": "system",
                        "content": "You write factual short-form video scripts. Never invent facts. JSON only.",
                    },
                    {"role": "user", "content": prompt},
                ],
            },
            timeout=40,
        )
        if resp.status_code >= 400:
            warn(f"Groq HTTP {resp.status_code}")
            return None
        return resp.json()["choices"][0]["message"]["content"]
    except Exception as exc:
        warn(f"Groq failed: {exc}")
        return None


def _gemini_complete(prompt: str) -> Optional[str]:
    key = env("GEMINI_API_KEY")
    if not key:
        return None
    url = (
        "https://generativelanguage.googleapis.com/v1beta/models/"
        f"{env('GEMINI_MODEL', 'gemini-2.0-flash')}:generateContent"
    )
    try:
        resp = requests.post(
            url,
            params={"key": key},
            json={
                "contents": [{"parts": [{"text": prompt}]}],
                "generationConfig": {"temperature": 0.4},
            },
            timeout=40,
        )
        if resp.status_code >= 400:
            warn(f"Gemini HTTP {resp.status_code}")
            return None
        data = resp.json()
        return data["candidates"][0]["content"]["parts"][0]["text"]
    except Exception as exc:
        warn(f"Gemini failed: {exc}")
        return None


def _openai_compatible(prompt: str) -> Optional[str]:
    key = env("OPENAI_API_KEY")
    if not key:
        return None
    base = env("OPENAI_BASE_URL", "https://api.openai.com/v1").rstrip("/")
    model = env("OPENAI_MODEL", "gpt-4o-mini")
    try:
        resp = requests.post(
            f"{base}/chat/completions",
            headers={
                "Authorization": f"Bearer {key}",
                "Content-Type": "application/json",
            },
            json={
                "model": model,
                "temperature": 0.4,
                "messages": [
                    {
                        "role": "system",
                        "content": "You write factual short-form video scripts. Never invent facts. JSON only.",
                    },
                    {"role": "user", "content": prompt},
                ],
            },
            timeout=40,
        )
        if resp.status_code >= 400:
            warn(f"OpenAI-compatible HTTP {resp.status_code}")
            return None
        return resp.json()["choices"][0]["message"]["content"]
    except Exception as exc:
        warn(f"OpenAI-compatible failed: {exc}")
        return None


def _parse_llm_json(raw: str) -> Optional[dict[str, Any]]:
    raw = raw.strip()
    raw = re.sub(r"^```(?:json)?", "", raw).strip()
    raw = re.sub(r"```$", "", raw).strip()
    match = re.search(r"\{.*\}", raw, re.S)
    if not match:
        return None
    try:
        data = json.loads(match.group(0))
        if isinstance(data, dict):
            return data
    except json.JSONDecodeError:
        return None
    return None


def _plan_scenes(script: dict[str, Any], research: dict[str, Any]) -> list[dict[str, Any]]:
    units = [script.get("hook", "")]
    units.extend(script.get("body") or [])
    units.append(script.get("ending", ""))
    units = [u.strip() for u in units if u and u.strip()]
    keywords = research.get("keywords") or []
    topic = research.get("topic") or ""
    scenes = []
    for i, text in enumerate(units):
        scenes.append(
            {
                "index": i + 1,
                "text": text,
                "search_query": _visual_query(text, topic, keywords),
                "kind": "hook" if i == 0 else ("ending" if i == len(units) - 1 else "body"),
            }
        )
    return scenes


def _visual_query(text: str, topic: str, keywords: list[str]) -> str:
    from .research import clean_topic_query

    words = re.findall(r"[A-Za-z][A-Za-z0-9\-]{3,}", text)
    stop = {
        "this", "that", "with", "from", "have", "most", "people", "about",
        "actually", "follow", "short", "facts", "true", "real", "never",
        "hear", "want", "like", "more", "next", "stop", "scrolling",
        "amazing", "insane", "nonprofit", "organization", "subscribe",
    }
    useful = [w for w in words if w.lower() not in stop][:5]
    core = clean_topic_query(topic)
    seed = []
    if keywords:
        seed.append(keywords[0])
    if core:
        seed.append(core)
    query = " ".join(unique_keep_order(seed + useful)) or topic
    low = query.lower()
    if "minecraft" in low:
        query = "minecraft overworld landscape gameplay"
    elif "space" in low:
        query = "outer space galaxy stars nebula"
    elif "engineering" in low:
        query = "engineering construction bridge machines"
    return query[:80]
