"""Find relevant royalty-free video/images with provider fallbacks."""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Optional
from urllib.parse import quote

from .config_loader import env
from .utils import (
    cache_path,
    download_file,
    extension_from_url,
    http_get,
    info,
    warn,
)


def find_visuals_for_scenes(
    scenes: list[dict[str, Any]],
    topic: str,
    cache_dir: Path,
    visuals_cfg: dict[str, Any],
) -> list[dict[str, Any]]:
    used_urls: set[str] = set()
    results: list[dict[str, Any]] = []
    prefer_video = bool(visuals_cfg.get("prefer_video", True))

    for scene in scenes:
        query = scene.get("search_query") or topic
        info(f"Visual search: {query}")
        asset = None
        if prefer_video:
            asset = _search_video(query, cache_dir, used_urls)
        if asset is None:
            asset = _search_image(query, cache_dir, used_urls)
        if asset is None:
            asset = _search_video(topic, cache_dir, used_urls)
        if asset is None:
            asset = _search_image(topic, cache_dir, used_urls)
        if asset is None:
            warn(f"No media for '{query}', will use generated backdrop")
            asset = {
                "kind": "generated",
                "path": None,
                "query": query,
                "source": "generated",
                "attribution": "",
            }
        else:
            used_urls.add(asset.get("url") or asset.get("path") or "")
        scene_out = dict(scene)
        scene_out["visual"] = asset
        results.append(scene_out)
    return results


def _search_video(query: str, cache_dir: Path, used: set[str]) -> Optional[dict[str, Any]]:
    for fn in (_pexels_videos, _pixabay_videos):
        try:
            hits = fn(query)
        except Exception as exc:
            warn(f"{fn.__name__} error: {exc}")
            hits = []
        asset = _download_first(hits, cache_dir, used, kind="video")
        if asset:
            return asset
    return None


def _search_image(query: str, cache_dir: Path, used: set[str]) -> Optional[dict[str, Any]]:
    for fn in (_pexels_photos, _pixabay_photos, _unsplash_photos, _wikimedia_images):
        try:
            hits = fn(query)
        except Exception as exc:
            warn(f"{fn.__name__} error: {exc}")
            hits = []
        asset = _download_first(hits, cache_dir, used, kind="image")
        if asset:
            return asset
    return None


def _download_first(
    hits: list[dict[str, Any]],
    cache_dir: Path,
    used: set[str],
    kind: str,
) -> Optional[dict[str, Any]]:
    for hit in hits:
        url = hit.get("url")
        if not url or url in used:
            continue
        ext = ".mp4" if kind == "video" else extension_from_url(url, ".jpg")
        dest = cache_path(cache_dir, "visuals", url, ext)
        headers = hit.get("headers")
        if download_file(url, dest, headers=headers):
            return {
                "kind": kind,
                "path": str(dest),
                "url": url,
                "query": hit.get("query", ""),
                "source": hit.get("source", ""),
                "attribution": hit.get("attribution", ""),
                "page_url": hit.get("page_url", ""),
            }
    return None


def _pexels_videos(query: str) -> list[dict[str, Any]]:
    key = env("PEXELS_API_KEY")
    if not key:
        return []
    resp = http_get(
        "https://api.pexels.com/v1/videos/search",
        headers={"Authorization": key},
        params={"query": query, "per_page": 12, "orientation": "portrait"},
    )
    if resp is None:
        resp = http_get(
            "https://api.pexels.com/v1/videos/search",
            headers={"Authorization": key},
            params={"query": query, "per_page": 12},
        )
    if resp is None:
        return []
    out = []
    for video in resp.json().get("videos", []):
        files = video.get("video_files") or []
        files = sorted(files, key=lambda f: abs((f.get("width") or 0) - 1080))
        pick = None
        for f in files:
            if (f.get("file_type") or "").lower() in ("video/mp4", "mp4", "") and f.get("link"):
                if (f.get("width") or 0) >= 720 or (f.get("height") or 0) >= 720:
                    pick = f
                    break
        if pick is None and files:
            pick = files[0]
        if not pick or not pick.get("link"):
            continue
        out.append(
            {
                "url": pick["link"],
                "source": "pexels",
                "query": query,
                "page_url": video.get("url", ""),
                "attribution": f"Video by {video.get('user', {}).get('name', 'Pexels')} on Pexels",
            }
        )
    return out


def _pexels_photos(query: str) -> list[dict[str, Any]]:
    key = env("PEXELS_API_KEY")
    if not key:
        return []
    resp = http_get(
        "https://api.pexels.com/v1/search",
        headers={"Authorization": key},
        params={"query": query, "per_page": 12, "orientation": "portrait"},
    )
    if resp is None:
        return []
    out = []
    for photo in resp.json().get("photos", []):
        src = photo.get("src") or {}
        url = src.get("large2x") or src.get("large") or src.get("original")
        if not url:
            continue
        out.append(
            {
                "url": url,
                "source": "pexels",
                "query": query,
                "page_url": photo.get("url", ""),
                "attribution": f"Photo by {photo.get('photographer', 'Pexels')} on Pexels",
            }
        )
    return out


def _pixabay_videos(query: str) -> list[dict[str, Any]]:
    key = env("PIXABAY_API_KEY")
    if not key:
        return []
    resp = http_get(
        "https://pixabay.com/api/videos/",
        params={"key": key, "q": query, "per_page": 12, "safesearch": "true"},
    )
    if resp is None:
        return []
    out = []
    for video in resp.json().get("hits", []):
        vids = video.get("videos") or {}
        pick = vids.get("large") or vids.get("medium") or vids.get("small") or {}
        url = pick.get("url")
        if not url:
            continue
        out.append(
            {
                "url": url,
                "source": "pixabay",
                "query": query,
                "page_url": video.get("pageURL", ""),
                "attribution": "Video from Pixabay",
            }
        )
    return out


def _pixabay_photos(query: str) -> list[dict[str, Any]]:
    key = env("PIXABAY_API_KEY")
    if not key:
        return []
    resp = http_get(
        "https://pixabay.com/api/",
        params={
            "key": key,
            "q": query,
            "image_type": "photo",
            "orientation": "vertical",
            "per_page": 12,
            "safesearch": "true",
        },
    )
    if resp is None:
        return []
    out = []
    for photo in resp.json().get("hits", []):
        url = photo.get("largeImageURL") or photo.get("webformatURL")
        if not url:
            continue
        out.append(
            {
                "url": url,
                "source": "pixabay",
                "query": query,
                "page_url": photo.get("pageURL", ""),
                "attribution": f"Photo by {photo.get('user', 'Pixabay')} on Pixabay",
            }
        )
    return out


def _unsplash_photos(query: str) -> list[dict[str, Any]]:
    key = env("UNSPLASH_ACCESS_KEY")
    if not key:
        return []
    resp = http_get(
        "https://api.unsplash.com/search/photos",
        headers={"Accept-Version": "v1"},
        params={
            "query": query,
            "per_page": 10,
            "orientation": "portrait",
            "client_id": key,
        },
    )
    if resp is None:
        return []
    out = []
    for photo in resp.json().get("results", []):
        url = (photo.get("urls") or {}).get("regular") or (photo.get("urls") or {}).get("full")
        if not url:
            continue
        name = (photo.get("user") or {}).get("name") or "Unsplash"
        out.append(
            {
                "url": url,
                "source": "unsplash",
                "query": query,
                "page_url": (photo.get("links") or {}).get("html", ""),
                "attribution": f"Photo by {name} on Unsplash",
            }
        )
    return out


def _wikimedia_images(query: str) -> list[dict[str, Any]]:
    resp = http_get(
        "https://commons.wikimedia.org/w/api.php",
        params={
            "action": "query",
            "generator": "search",
            "gsrsearch": query,
            "gsrnamespace": "6",
            "gsrlimit": "12",
            "prop": "imageinfo",
            "iiprop": "url|mime|size",
            "iiurlwidth": "1280",
            "format": "json",
        },
    )
    if resp is None:
        return []
    pages = resp.json().get("query", {}).get("pages", {})
    out = []
    allowed = {"image/jpeg", "image/png", "image/webp"}
    for page in pages.values():
        infos = page.get("imageinfo") or []
        if not infos:
            continue
        info_ = infos[0]
        mime = (info_.get("mime") or "").lower()
        if mime not in allowed:
            continue
        url = info_.get("thumburl") or info_.get("url")
        if not url:
            continue
        title = page.get("title", "Wikimedia Commons")
        out.append(
            {
                "url": url,
                "source": "wikimedia",
                "query": query,
                "page_url": info_.get("descriptionurl", ""),
                "attribution": f"{title} — Wikimedia Commons",
            }
        )
    return out


def _wikimedia_videos(query: str) -> list[dict[str, Any]]:
    resp = http_get(
        "https://commons.wikimedia.org/w/api.php",
        params={
            "action": "query",
            "generator": "search",
            "gsrsearch": f"{query} filetype:video",
            "gsrnamespace": "6",
            "gsrlimit": "8",
            "prop": "imageinfo",
            "iiprop": "url|mime|size",
            "format": "json",
        },
    )
    if resp is None:
        return []
    pages = resp.json().get("query", {}).get("pages", {})
    out = []
    for page in pages.values():
        infos = page.get("imageinfo") or []
        if not infos:
            continue
        info_ = infos[0]
        mime = (info_.get("mime") or "").lower()
        url = info_.get("url") or ""
        if "video" not in mime and not url.lower().endswith((".mp4", ".webm", ".ogv")):
            continue
        if url.lower().endswith(".ogv"):
            continue
        if not url:
            continue
        out.append(
            {
                "url": url,
                "source": "wikimedia",
                "query": query,
                "page_url": info_.get("descriptionurl", ""),
                "attribution": f"{page.get('title', 'Wikimedia')} — Wikimedia Commons",
            }
        )
    return out


def prefetch(urls_and_dests: list[tuple[str, Path]]) -> None:
    def _one(item: tuple[str, Path]) -> bool:
        return download_file(item[0], item[1])

    with ThreadPoolExecutor(max_workers=4) as pool:
        futs = [pool.submit(_one, item) for item in urls_and_dests]
        for _ in as_completed(futs):
            pass
