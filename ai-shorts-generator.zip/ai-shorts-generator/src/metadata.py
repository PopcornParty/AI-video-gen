"""YouTube title, description, hashtags, and tags."""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from .config_loader import env
from .utils import save_json, save_text, unique_keep_order


def generate_metadata(
    topic: str,
    script: dict[str, Any],
    research: dict[str, Any],
    out_dir: Path,
) -> dict[str, Any]:
    llm = _try_llm_meta(topic, script)
    title = (llm or {}).get("title") or _title(topic, script)
    description = (llm or {}).get("description") or _description(topic, script, research)
    hashtags = (llm or {}).get("hashtags") or _hashtags(topic)
    tags = (llm or {}).get("tags") or _tags(topic, research)

    title = _clean_title(title, topic)
    hashtags = _normalize_hashtags(hashtags)
    tags = unique_keep_order(tags)[:20]

    payload = {
        "title": title,
        "description": description,
        "hashtags": hashtags,
        "tags": tags,
        "topic": topic,
        "script_provider": script.get("provider"),
    }
    save_text(out_dir / "title.txt", title + "\n")
    desc_full = description
    if hashtags:
        desc_full = description.rstrip() + "\n\n" + " ".join(hashtags) + "\n"
    save_text(out_dir / "description.txt", desc_full)
    save_text(out_dir / "tags.txt", ",".join(tags) + "\n")
    save_json(out_dir / "metadata.json", payload)
    return payload


def _title(topic: str, script: dict[str, Any]) -> str:
    seed = (script.get("title_seed") or topic).strip()
    seed = re.sub(r"\s+", " ", seed)
    low = seed.lower()
    if low == topic.lower() or len(seed) < 16:
        seed = f"{topic} that sound fake"
    if len(seed) > 70:
        seed = seed[:67].rstrip() + "…"
    return seed


def _clean_title(title: str, topic: str) -> str:
    title = re.sub(r"\s+", " ", title).strip().strip('"')
    title = title.replace("#", "")
    if len(title) < 8:
        title = topic
    return title[:90]


def _description(topic: str, script: dict[str, Any], research: dict[str, Any]) -> str:
    hook = script.get("hook") or topic
    sources = research.get("sources") or []
    lines = [
        hook,
        "",
        f"A short, sourced look at {topic}.",
        "",
        "Key points:",
    ]
    for sentence in (script.get("body") or [])[:5]:
        lines.append(f"• {sentence}")
    if sources:
        lines += ["", "Sources:"]
        for src in sources[:5]:
            lines.append(f"- {src.get('title')}: {src.get('url')}")
    lines += [
        "",
        "Visuals are royalty-free stock / Wikimedia media. Music is royalty-free or generated.",
        "This project does not use copyrighted movie or game cutscenes.",
    ]
    return "\n".join(lines).strip() + "\n"


def _hashtags(topic: str) -> list[str]:
    words = re.findall(r"[A-Za-z][A-Za-z0-9]+", topic)
    tags = ["#shorts", "#youtubeshorts", "#facts"]
    if words:
        tags.append("#" + "".join(w.capitalize() for w in words[:3]))
        tags.append("#" + words[0].lower())
    return unique_keep_order(tags)[:8]


def _tags(topic: str, research: dict[str, Any]) -> list[str]:
    tags = [topic, "shorts", "facts", "educational"]
    tags.extend(research.get("keywords") or [])
    return [t for t in unique_keep_order(tags) if 2 < len(t) < 40]


def _normalize_hashtags(items: list[str]) -> list[str]:
    out = []
    for item in items:
        t = str(item).strip()
        if not t:
            continue
        if not t.startswith("#"):
            t = "#" + re.sub(r"[^A-Za-z0-9]", "", t)
        out.append(t)
    return unique_keep_order(out)[:10]


def _try_llm_meta(topic: str, script: dict[str, Any]) -> dict[str, Any] | None:
    key = env("GROQ_API_KEY") or env("GEMINI_API_KEY")
    if not key:
        return None
    # Keep metadata local-first so missing LLM keys never block export.
    return None
