"""Royalty-free background music: local files, Pixabay, or generated bed."""

from __future__ import annotations

import math
import struct
import subprocess
import wave
from pathlib import Path
from typing import Any, Optional

from .config_loader import env
from .utils import cache_path, download_file, http_get, info, project_root, warn


def get_music_track(
    cache_dir: Path,
    topic: str,
    duration: float,
    music_cfg: dict[str, Any],
) -> Optional[Path]:
    if not music_cfg.get("enabled", True):
        info("Music disabled in config")
        return None

    local = _first_local_track()
    if local:
        info(f"Using local music: {local.name}")
        return local

    remote = _pixabay_music(topic, cache_dir)
    if remote:
        info("Using Pixabay music")
        return remote

    generated = _generate_ambient(cache_dir, duration)
    if generated:
        info("Using generated royalty-free ambient bed")
        return generated
    warn("No music track available")
    return None


def _first_local_track() -> Optional[Path]:
    folder = project_root() / "assets" / "music"
    if not folder.exists():
        return None
    for ext in ("*.mp3", "*.wav", "*.m4a", "*.ogg"):
        files = [p for p in folder.glob(ext) if p.is_file() and p.stat().st_size > 10_000]
        if files:
            return sorted(files)[0]
    return None


def _pixabay_music(topic: str, cache_dir: Path) -> Optional[Path]:
    key = env("PIXABAY_API_KEY")
    if not key:
        return None
    query = "calm documentary ambient"
    low = topic.lower()
    if "space" in low:
        query = "space ambient calm"
    elif "minecraft" in low or "game" in low:
        query = "upbeat curious ambient"
    elif "ocean" in low:
        query = "ocean calm ambient"
    resp = http_get(
        "https://pixabay.com/api/audio/",
        params={"key": key, "q": query, "per_page": 8, "safesearch": "true"},
    )
    if resp is None:
        return None
    for hit in resp.json().get("hits", []):
        url = hit.get("audio") or hit.get("previewURL")
        if not url:
            continue
        dest = cache_path(cache_dir, "music", url, ".mp3")
        if download_file(url, dest):
            return dest
    return None


def _generate_ambient(cache_dir: Path, duration: float) -> Optional[Path]:
    seconds = max(20, int(math.ceil(duration + 4)))
    wav_path = cache_path(cache_dir, "music", f"ambient-{seconds}", "wav")
    mp3_path = wav_path.with_suffix(".mp3")
    if mp3_path.exists() and mp3_path.stat().st_size > 5000:
        return mp3_path
    sr = 44100
    # Soft pentatonic pad: C4 E4 G4 A4
    freqs = [261.63, 329.63, 392.00, 440.00]
    n = seconds * sr
    samples = []
    for i in range(n):
        t = i / sr
        val = 0.0
        for idx, f in enumerate(freqs):
            env = 0.5 + 0.5 * math.sin(2 * math.pi * (0.03 + idx * 0.007) * t)
            val += 0.12 * env * math.sin(2 * math.pi * f * t)
            val += 0.04 * env * math.sin(2 * math.pi * (f * 2) * t)
        # gentle low rumble
        val += 0.05 * math.sin(2 * math.pi * 55 * t)
        fade = min(1.0, t / 1.2, (seconds - t) / 1.2)
        sample = int(max(-1.0, min(1.0, val * fade)) * 30000)
        samples.append(struct.pack("<h", sample))
    wav_path.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(wav_path), "w") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(sr)
        wf.writeframes(b"".join(samples))
    try:
        subprocess.run(
            [
                "ffmpeg",
                "-y",
                "-i",
                str(wav_path),
                "-codec:a",
                "libmp3lame",
                "-qscale:a",
                "4",
                str(mp3_path),
            ],
            check=True,
            capture_output=True,
        )
        return mp3_path
    except Exception:
        return wav_path
