"""Assemble 9:16 Shorts with low memory: one scene at a time, then FFmpeg."""

from __future__ import annotations

import subprocess
from pathlib import Path
from typing import Any, Optional

from PIL import Image, ImageFont

from .utils import info, project_root, warn


def render_short(
    scenes: list[dict[str, Any]],
    audio_path: str,
    caption_groups: list[dict[str, Any]],
    music_path: Optional[Path],
    output_path: Path,
    cfg: dict[str, Any],
    work_dir: Path,
) -> Path:
    video_cfg = cfg["video"]
    cap_cfg = cfg["captions"]
    music_cfg = cfg["music"]
    W, H = int(video_cfg["width"]), int(video_cfg["height"])
    fps = int(video_cfg["fps"])
    work_dir.mkdir(parents=True, exist_ok=True)

    duration = _media_duration(audio_path)
    if duration < 1:
        raise RuntimeError("Narration audio is empty")

    scene_files = []
    for i, scene in enumerate(scenes):
        dest = work_dir / f"scene_{i:02d}.mp4"
        info(f"Rendering scene {i + 1}/{len(scenes)}")
        _render_scene(scene, dest, W, H, fps)
        scene_files.append(dest)

    concat_path = work_dir / "visuals.mp4"
    _ffmpeg_concat(scene_files, concat_path, fps)

    visuals_fit = work_dir / "visuals_fit.mp4"
    _fit_length(concat_path, visuals_fit, duration, fps)

    captioned = work_dir / "captioned.mp4"
    if cap_cfg.get("enabled", True) and caption_groups:
        info("Burning captions")
        ass_path = work_dir / "captions.ass"
        _write_ass(caption_groups, ass_path, W, H, cap_cfg)
        _burn_subtitles(visuals_fit, ass_path, captioned)
        if not captioned.exists():
            captioned = visuals_fit
    else:
        captioned = visuals_fit

    mixed_audio = work_dir / "mixed.m4a"
    _mix_audio(audio_path, music_path, mixed_audio, duration, music_cfg)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    info(f"Muxing final {W}x{H} @ {fps}fps")
    _mux(captioned, mixed_audio, output_path, video_cfg)
    if not output_path.exists() or output_path.stat().st_size < 10_000:
        raise RuntimeError("Final MP4 was not created")
    return output_path


def _media_duration(path: str) -> float:
    out = subprocess.check_output(
        [
            "ffprobe",
            "-v",
            "error",
            "-show_entries",
            "format=duration",
            "-of",
            "default=noprint_wrappers=1:nokey=1",
            path,
        ],
        text=True,
    ).strip()
    return float(out)


def _render_scene(scene: dict[str, Any], dest: Path, W: int, H: int, fps: int) -> None:
    duration = max(0.7, float(scene.get("duration") or (scene["end"] - scene["start"])))
    visual = scene.get("visual") or {}
    path = visual.get("path")
    kind = visual.get("kind")
    if kind == "video" and path and Path(path).exists():
        if _transcode_video_cover(path, dest, W, H, fps, duration):
            return
    if path and Path(path).exists():
        if _ken_burns_ffmpeg(path, dest, W, H, fps, duration, int(scene.get("index") or 0)):
            return
    _generated_scene(dest, W, H, fps, duration, int(scene.get("index") or 0))


def _transcode_video_cover(src: str, dest: Path, W: int, H: int, fps: int, duration: float) -> bool:
    src_dur = _probe_duration(src)
    start = 0.0
    if src_dur and src_dur > duration + 0.4:
        start = min(src_dur * 0.12, src_dur - duration)
    vf = f"scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},fps={fps}"
    cmd = [
        "ffmpeg", "-y", "-ss", f"{start:.3f}", "-t", f"{duration:.3f}", "-i", src,
        "-vf", vf, "-an", "-c:v", "libx264", "-preset", "veryfast", "-b:v", "6M",
        "-pix_fmt", "yuv420p", "-r", str(fps), str(dest),
    ]
    if _run(cmd) and dest.exists() and dest.stat().st_size > 1000:
        return True
    cmd = [
        "ffmpeg", "-y", "-stream_loop", "8", "-i", src, "-t", f"{duration:.3f}",
        "-vf", vf, "-an", "-c:v", "libx264", "-preset", "veryfast", "-b:v", "6M",
        "-pix_fmt", "yuv420p", str(dest),
    ]
    return _run(cmd) and dest.exists()


def _ken_burns_ffmpeg(
    src: str, dest: Path, W: int, H: int, fps: int, duration: float, index: int
) -> bool:
    z0 = 1.04
    z1 = 1.16 if index % 2 == 0 else 1.12
    frames = max(1, int(duration * fps))
    xf = "iw/2-(iw/zoom/2)"
    yf = "ih/2-(ih/zoom/2)"
    if index % 3 == 1:
        xf = "iw/2-(iw/zoom/2)+on*0.35"
        yf = "ih/2-(ih/zoom/2)-on*0.18"
    elif index % 3 == 2:
        xf = "iw/2-(iw/zoom/2)-on*0.28"
        yf = "ih/2-(ih/zoom/2)+on*0.22"
    vf = (
        f"scale=2400:-1,"
        f"zoompan=z='{z0}+({z1}-{z0})*on/{frames}':x='{xf}':y='{yf}':"
        f"d={frames}:s={W}x{H}:fps={fps}"
    )
    cmd = [
        "ffmpeg", "-y", "-loop", "1", "-i", src, "-t", f"{duration:.3f}",
        "-vf", vf, "-an", "-c:v", "libx264", "-preset", "veryfast", "-b:v", "6M",
        "-pix_fmt", "yuv420p", str(dest),
    ]
    return _run(cmd) and dest.exists()


def _generated_scene(dest: Path, W: int, H: int, fps: int, duration: float, index: int) -> None:
    palettes = [
        ("#0c1226", "#225c8c"),
        ("#140c20", "#5c285a"),
        ("#081c18", "#185a46"),
        ("#1c100a", "#78461c"),
    ]
    c1, c2 = palettes[index % len(palettes)]
    img_path = dest.with_suffix(".png")
    _write_gradient(img_path, min(W, 540), min(H, 960), c1, c2)
    if not _ken_burns_ffmpeg(str(img_path), dest, W, H, fps, duration, index):
        cmd = [
            "ffmpeg", "-y", "-loop", "1", "-i", str(img_path), "-t", f"{duration:.3f}",
            "-vf", f"scale={W}:{H}", "-c:v", "libx264", "-pix_fmt", "yuv420p", str(dest),
        ]
        if not _run(cmd):
            raise RuntimeError("Could not create fallback scene")


def _write_gradient(path: Path, W: int, H: int, c1: str, c2: str) -> None:
    a = _hex(c1)
    b = _hex(c2)
    img = Image.new("RGB", (W, H))
    px = img.load()
    for y in range(H):
        t = y / max(H - 1, 1)
        rgb = tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))
        for x in range(W):
            px[x, y] = rgb
    path.parent.mkdir(parents=True, exist_ok=True)
    img.save(path, "PNG")


def _hex(value: str) -> tuple[int, int, int]:
    value = value.lstrip("#")
    return tuple(int(value[i : i + 2], 16) for i in (0, 2, 4))


def _ffmpeg_concat(files: list[Path], dest: Path, fps: int) -> None:
    lst = dest.with_suffix(".txt")
    lines = [f"file '{f.resolve().as_posix()}'" for f in files]
    lst.write_text("\n".join(lines) + "\n", encoding="utf-8")
    cmd = [
        "ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", str(lst),
        "-c", "copy", str(dest),
    ]
    if _run(cmd):
        return
    cmd = [
        "ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", str(lst),
        "-c:v", "libx264", "-pix_fmt", "yuv420p", "-r", str(fps), str(dest),
    ]
    if not _run(cmd):
        raise RuntimeError("FFmpeg concat failed")


def _fit_length(src: Path, dest: Path, duration: float, fps: int) -> None:
    cmd = [
        "ffmpeg", "-y", "-stream_loop", "-1", "-i", str(src), "-t", f"{duration:.3f}",
        "-c:v", "libx264", "-preset", "veryfast", "-b:v", "6M", "-pix_fmt", "yuv420p",
        "-r", str(fps), str(dest),
    ]
    if not _run(cmd):
        raise RuntimeError("Could not fit video length to narration")


def _write_ass(
    groups: list[dict[str, Any]], path: Path, W: int, H: int, cap_cfg: dict[str, Any]
) -> None:
    font = Path(cap_cfg.get("font_name") or "Lato-Bold.ttf").stem
    size = int(cap_cfg.get("font_size", 68))
    header = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {W}
PlayResY: {H}
WrapStyle: 2
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,{font},{size},&H00FFFFFF,&H0000FFFF,&H00000000,&H80000000,-1,0,0,0,100,100,0,0,1,4,0,2,70,70,{int(H * 0.28)},1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    events = []
    highlight = cap_cfg.get("highlight_color", "#FFD60A")
    ass_hl = _ass_color(highlight)
    for g in groups:
        words = g.get("words") or g["text"].split()
        emphasis = set(g.get("emphasis") or [])
        parts = []
        for i, w in enumerate(words):
            safe = _ass_escape(w)
            if i in emphasis:
                parts.append(r"{\c" + ass_hl + "}" + safe + r"{\c&H00FFFFFF&}")
            else:
                parts.append(safe)
        text = " ".join(parts)
        events.append(
            f"Dialogue: 0,{_ass_time(g['start'])},{_ass_time(g['end'])},Default,,0,0,0,,{text}"
        )
    path.write_text(header + "\n".join(events) + "\n", encoding="utf-8")


def _ass_color(hex_color: str) -> str:
    h = hex_color.lstrip("#")
    if len(h) != 6:
        return "&H0000D6FF&"
    r, g, b = h[0:2], h[2:4], h[4:6]
    return f"&H00{b}{g}{r}&"


def _ass_escape(text: str) -> str:
    return text.replace("\\\\", r"\\\\").replace("{", "(").replace("}", ")")


def _ass_time(seconds: float) -> str:
    seconds = max(0.0, seconds)
    h = int(seconds // 3600)
    m = int((seconds % 3600) // 60)
    s = seconds % 60
    return f"{h}:{m:02d}:{s:05.2f}"


def _burn_subtitles(video: Path, ass_path: Path, dest: Path) -> None:
    fonts = project_root() / "assets" / "fonts"
    filt = f"ass={_ffmpeg_path(ass_path)}:fontsdir={_ffmpeg_path(fonts)}"
    cmd = [
        "ffmpeg", "-y", "-i", str(video), "-vf", filt,
        "-c:v", "libx264", "-preset", "veryfast", "-b:v", "6M", "-pix_fmt", "yuv420p", "-an", str(dest),
    ]
    if not _run(cmd):
        warn("Caption burn failed, exporting without captions")
        subprocess.run(["cp", str(video), str(dest)], check=False)


def _mix_audio(
    narration: str,
    music_path: Optional[Path],
    dest: Path,
    duration: float,
    music_cfg: dict[str, Any],
) -> None:
    if music_path and Path(music_path).exists() and music_cfg.get("enabled", True):
        vol = float(music_cfg.get("duck_volume", 0.07))
        cmd = [
            "ffmpeg", "-y", "-i", narration, "-stream_loop", "-1", "-i", str(music_path),
            "-t", f"{duration:.3f}",
            "-filter_complex",
            f"[1:a]volume={vol}[m];[0:a][m]amix=inputs=2:duration=first:dropout_transition=2[a]",
            "-map", "[a]", "-c:a", "aac", "-b:a", "192k", str(dest),
        ]
        if _run(cmd):
            return
        warn("Music mix failed, using narration only")
    cmd = [
        "ffmpeg", "-y", "-i", narration, "-t", f"{duration:.3f}",
        "-ar", "44100", "-ac", "2", "-c:a", "aac", "-b:a", "192k", str(dest),
    ]
    if not _run(cmd):
        raise RuntimeError("Could not encode narration audio")


def _mux(video: Path, audio: Path, dest: Path, video_cfg: dict[str, Any]) -> None:
    cmd = [
        "ffmpeg", "-y", "-i", str(video), "-i", str(audio),
        "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-shortest",
        "-movflags", "+faststart", str(dest),
    ]
    if _run(cmd):
        return
    cmd = [
        "ffmpeg", "-y", "-i", str(video), "-i", str(audio),
        "-c:v", video_cfg.get("codec", "libx264"), "-pix_fmt", "yuv420p",
        "-b:v", video_cfg.get("bitrate", "8M"), "-c:a", "aac", "-shortest",
        "-movflags", "+faststart", str(dest),
    ]
    if not _run(cmd):
        raise RuntimeError("Final mux failed")


def _probe_duration(path: str) -> float:
    try:
        return _media_duration(path)
    except Exception:
        return 0.0


def _run(cmd: list[str]) -> bool:
    proc = subprocess.run(cmd, capture_output=True, text=True)
    if proc.returncode != 0:
        err = (proc.stderr or "")[-500:]
        warn(f"ffmpeg: {err.strip()}")
        return False
    return True


def _ffmpeg_path(path: Path) -> str:
    return path.resolve().as_posix().replace("\\\\", "/").replace(":", "\\\\:")


def _caption_preview_font(cap_cfg: dict[str, Any]):
    font_path = project_root() / "assets" / "fonts" / cap_cfg.get("font_name", "Lato-Bold.ttf")
    try:
        return ImageFont.truetype(str(font_path), int(cap_cfg.get("font_size", 68)))
    except Exception:
        return ImageFont.load_default()
