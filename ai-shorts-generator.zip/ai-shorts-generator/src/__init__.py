"""AI YouTube Shorts generator package."""

__version__ = "1.0.0"
