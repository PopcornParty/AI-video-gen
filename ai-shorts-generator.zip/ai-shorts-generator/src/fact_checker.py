"""Keep scripts anchored to researched sources. Do not invent numbers."""

from __future__ import annotations

import re
from typing import Any

from .utils import unique_keep_order


_NUMBER = re.compile(r"\d[\d,]*(?:\.\d+)?")


def filter_script_to_sources(
    sentences: list[str],
    facts: list[str],
    allow_cta: bool = True,
) -> list[str]:
    """Drop body sentences that introduce numbers not present in source facts."""
    source_blob = " ".join(facts).lower()
    source_numbers = set(_NUMBER.findall(source_blob.replace(",", "")))
    kept: list[str] = []
    for sentence in sentences:
        low = sentence.lower()
        if allow_cta and _is_cta(low):
            kept.append(sentence)
            continue
        nums = [n.replace(",", "") for n in _NUMBER.findall(sentence)]
        invented = [n for n in nums if n not in source_numbers and n not in {"1", "2", "3"}]
        if invented and not _sentence_supported(low, facts):
            continue
        kept.append(sentence)
    return unique_keep_order(kept)


def _sentence_supported(low: str, facts: list[str]) -> bool:
    tokens = [t for t in re.findall(r"[a-z0-9]{4,}", low) if t not in _STOP]
    if not tokens:
        return True
    for fact in facts:
        f = fact.lower()
        hits = sum(1 for t in tokens if t in f)
        if hits >= max(2, len(tokens) // 3):
            return True
    return False


def _is_cta(low: str) -> bool:
    return any(
        phrase in low
        for phrase in (
            "follow",
            "subscribe",
            "watch more",
            "another short",
            "drop a follow",
        )
    )


_STOP = {
    "this",
    "that",
    "with",
    "from",
    "have",
    "been",
    "were",
    "they",
    "them",
    "their",
    "about",
    "which",
    "when",
    "what",
    "your",
    "more",
    "most",
    "into",
    "over",
    "also",
    "than",
    "then",
    "just",
    "like",
    "some",
    "could",
    "would",
    "there",
    "these",
    "those",
}


def sources_text(research: dict[str, Any]) -> str:
    lines = [f"Topic: {research.get('topic', '')}", "", "Sources used:"]
    for src in research.get("sources") or []:
        lines.append(f"- {src.get('title', 'Source')}: {src.get('url', '')}")
    lines += ["", "Facts considered:"]
    for fact in research.get("facts") or []:
        lines.append(f"- {fact}")
    return "\n".join(lines).strip() + "\n"
